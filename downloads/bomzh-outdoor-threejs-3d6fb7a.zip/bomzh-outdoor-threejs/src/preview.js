import * as THREE from 'three';
import {OUTDOOR_LOCATIONS, loadOutdoorTemplates, createOutdoorWorld, createReferenceLook} from './environment.js';
const canvas = document.querySelector('#preview');
const status = document.querySelector('#status');
try {
  const params = new URLSearchParams(location.search);
  const lowQuality = params.get('quality') === 'low';
  const renderer = new THREE.WebGLRenderer({canvas, antialias:!lowQuality});
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.5));
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(40, 1, .1, 100);
  const templates = await loadOutdoorTemplates();
  const reference = createReferenceLook(scene, renderer, templates, {lowQuality});
  const select = document.querySelector('#location');
  for (const item of OUTDOOR_LOCATIONS) select.add(new Option(item.name, item.id));
  select.value = OUTDOOR_LOCATIONS.some(item => item.id === params.get('yard')) ? params.get('yard') : 'street';
  const world = createOutdoorWorld(templates, {sectionForIndex:() => select.value, lowQuality});
  scene.add(world.root);
  const slider = document.querySelector('#position');
  let x = 13, wide = false, time = 0, previous = performance.now();
  const keys = new Set();
  const setX = value => {x = THREE.MathUtils.clamp(value, 1, 25); slider.value = x;};
  slider.oninput = () => setX(Number(slider.value));
  const overview = document.querySelector('#overview');
  overview.onclick = () => {wide = !wide; overview.textContent = wide ? 'Игровой ракурс' : 'Общий план';};
  addEventListener('keydown', event => {
    if (event.target.matches('select,input,button')) return;
    if (['ArrowLeft', 'ArrowRight', 'KeyA', 'KeyD'].includes(event.code)) {keys.add(event.code); event.preventDefault();}
  });
  addEventListener('keyup', event => keys.delete(event.code));
  addEventListener('blur', () => keys.clear());
  let pointer = null;
  canvas.onpointerdown = event => {pointer = event.clientX; canvas.setPointerCapture(event.pointerId);};
  canvas.onpointermove = event => {if (pointer !== null) {setX(x - (event.clientX - pointer) * .025); pointer = event.clientX;}};
  canvas.onpointerup = canvas.onpointercancel = () => {pointer = null;};
  function resize() {
    const w = innerWidth, h = innerHeight;
    renderer.setSize(w, h);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    reference.resize(w, h);
  }
  addEventListener('resize', resize);
  resize();
  const target = new THREE.Vector3();
  function frame(now) {
    const dt = Math.min((now - previous) / 1000, .05);
    previous = now; time += dt;
    const direction = Number(keys.has('ArrowRight') || keys.has('KeyD')) - Number(keys.has('ArrowLeft') || keys.has('KeyA'));
    if (direction) setX(x + direction * dt * 3);
    const mobile = innerWidth < 700;
    camera.fov = mobile ? 53 : 40;
    const distance = wide ? (mobile ? 15 : 13) : (mobile ? 7.6 : 6.2);
    target.set(x + .25, wide ? 1.5 : 1, wide ? -2.5 : .3);
    camera.position.set(target.x + 1.2, target.y + distance * (wide ? .22 : .13), target.z + distance);
    camera.lookAt(target);
    camera.updateProjectionMatrix();
    reference.follow(x);
    world.update({x, time, dt, camera});
    reference.render(camera, target, dt);
    status.textContent = `${OUTDOOR_LOCATIONS.find(item => item.id === select.value).name} · X ${x.toFixed(1)} м`;
    window.outdoorPreview = {ready:true, location:select.value, x, chunks:world.chunks.size,
      templates:templates.sections.size, frames:(window.outdoorPreview?.frames ?? 0) + 1};
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
} catch (error) {
  status.textContent = `Ошибка загрузки: ${error.message}`;
  console.error(error);
}
